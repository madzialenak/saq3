package com.lab3.interfaces;

public interface Currency {

	String getSymbol();
	
}
