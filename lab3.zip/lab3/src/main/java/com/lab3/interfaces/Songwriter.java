package com.lab3.interfaces;

import com.lab3.domain.Song;

public interface Songwriter {

	void compose (Song song);
	
}
