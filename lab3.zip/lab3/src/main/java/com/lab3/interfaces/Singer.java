package com.lab3.interfaces;

import com.lab3.domain.Song;

public interface Singer {

	void perform (Song song);
	
}
