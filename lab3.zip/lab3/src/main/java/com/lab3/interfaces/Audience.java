package com.lab3.interfaces;

import com.lab3.domain.Ticket;

public interface Audience {

	void purchase (Ticket number, Ticket price);
	void refund (Ticket number, Ticket price);
	
}
