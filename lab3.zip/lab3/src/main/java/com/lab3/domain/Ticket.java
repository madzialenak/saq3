package com.lab3.domain;

public class Ticket {

	
	private int number;
	private double price;
	
	public Ticket(int number, double price){
		this.number = number;
		this.price = price;
	}
	
}
