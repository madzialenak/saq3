package com.lab3.domain;

import com.lab3.interfaces.Audience;
import com.lab3.domain.Person;

public class AudienceImpl extends Person implements Audience{

	public Audience(String firstname, String lastname, int age) {
		super(firstname, lastname, age);
	}
	
	public void purchase (Ticket number, Ticket price) {
		
		System.out.println(firstname + " " + lastname + " got " + number + " for " + price);
	}
}
