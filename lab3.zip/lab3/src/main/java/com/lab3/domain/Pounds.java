package com.lab3.domain;

import com.lab3.interfaces.Currency;

public class Pounds implements Currency{

	private static final String GBP = "GBP";
	
	public String getSymbol() {
		return GBP;
	}
	
	
}
