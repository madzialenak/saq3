package com.lab3.domain;

import com.lab3.domain.Song;
import com.lab3.interfaces.Songwriter;

public class SongWriterImpl extends Person implements Songwriter{

	
	private Song song;
	
public SongWriterImpl (String firstname, String lastname, int age, Song song) {
	super(firstname, lastname, age);
	this.song = song;
	System.out.println("fistname: "+ firstname +" lastname: "+ lastname +" age: " + age
			+" song name: "+ song.getName() + " song lyrics: "+ song.getLyrics());
}

public SongWriterImpl() {
	super();
}

public Song getSong() {
	return song;
}

public void setSong(Song song) {
	this.song = song;
}


public void Compose(Song song) {
	System.out.println("Composer: " + getFirstname() + " " + getFirstname() + " composed a song called " + song.getName() + ". This song has the following lyrics " + song.getLyrics());
}

@Override
public void compose(Song song) {
	// TODO Auto-generated method stub
	
}



	
}
