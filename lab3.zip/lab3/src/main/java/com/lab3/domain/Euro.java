package com.lab3.domain;

import com.lab3.interfaces.Currency;

public class Euro implements Currency{

	private static final String EUR = "EUR";
	
	public String getSymbol() {
		return EUR;
	}
	
}
