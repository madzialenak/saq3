package com.lab3.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.lab3.interfaces.Singer;

public class SingerImpl extends Person implements Singer{

	@Autowired
	private Song song;
	
	public SingerImpl(String firstname, String lastname, int age, Song song){
		super(firstname, lastname,age);
		this.song=song;		
	}
	
	public SingerImpl(){
		super();
	}

	@Override
	public void perform(Song song) {
		// TODO Auto-generated method stub
		
	}

	public Song getSong() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Autowired
	@Qualifier("song")
		public void setSong(Song song) {
			this.song = song;
		}
	
}
