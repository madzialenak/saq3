package com.lab3;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lab3.domain.SongWriterImpl;
import com.lab3.domain.Stage;
import com.lab3.domain.Ticket;
import com.lab3.interfaces.Currency;
import com.lab3.interfaces.Songwriter;
import com.lab3.domain.CollectionsExample;
import com.lab3.domain.SingerImpl;
import com.lab3.domain.Song;

public class App {
	
	private static ApplicationContext context;
	public static void main(String[] args) {
		
		context=new ClassPathXmlApplicationContext
                ("configuration.xml"); 
		
	/** Simple bean blank constructor **/
	Songwriter simpleBeanExample=(Songwriter)context.
              getBean("ourFirstBean"); 
	
	SongWriterImpl songwriter=(SongWriterImpl)context.getBean("mary");
	System.out.println("The songwriters firstname is: "+ songwriter.getFirstname() + ": The songwriters lastname is: "+ songwriter.getLastname() +
	        " The songwriters age is: " + songwriter.getAge() + " The songwriters song name is: " + songwriter.getSong().getName() + " The songwriters song lyrics are: "+
	        songwriter.getSong().getLyrics());
           
	 Song setterDISong =(Song)context.getBean("setterBeanSong");
	 System.out.println("Song name is: "+ setterDISong.getName());
	 System.out.println("Song lyrics are: "+setterDISong.getLyrics());  
	 
	 SongWriterImpl setterDISongwriter =(SongWriterImpl)context.getBean("setterSongwriter");
	 System.out.println("Songwriter firstname is: "+ setterDISongwriter.getFirstname());
	 System.out.println("Songwriter second name is: "+setterDISongwriter.getLastname());
	 System.out.println("Songwriter age is: "+setterDISongwriter.getAge());
	 System.out.println("Songwriter song details are: Song name: "+setterDISongwriter.getSong().getName()+
	         		" Song lyrics are: "+setterDISongwriter.getSong().getLyrics());
	
	
	context=new ClassPathXmlApplicationContext("configuration.xml");
	Currency currency=(Currency)context.getBean("currency");
	System.out.println("Currency symbol: " + currency.getSymbol());
	
	/**Singleton Example
	* Even when we create 2 bean instances of the object Stage the same instance is returned.
	**/
	Stage stage=(Stage)context.getBean("theStage");
	System.out.println("Stage instance value: "+ stage.toString());
	Stage stage1=(Stage)context.getBean("theStage1");
	System.out.println("Stage instance value: "+ stage1.toString());
	Ticket ticketSingleton=(Ticket)context.getBean("ticket");
	 System.out.println("Instance:"+ ticketSingleton.toString());
	 Ticket ticketSingleton1=(Ticket)context.getBean("ticket");
	 System.out.println("Instance:"+ ticketSingleton1.toString());
	 Ticket ticketPrototype=(Ticket)context.getBean("ticketPrototype");
	 System.out.println("Instance:"+ ticketPrototype.toString());
	 Ticket ticketPrototypeAnother=(Ticket)context.getBean("ticketPrototype");
	 System.out.println("Instance:"+ ticketPrototypeAnother.toString());
	
	 CollectionsExample javaCollectionExample=(CollectionsExample)context.getBean("javaCollectionExample");
	 javaCollectionExample.getInstrumentList();
	 javaCollectionExample.getInstrumentSet();
	 javaCollectionExample.getInstrumentMap();
	 javaCollectionExample.getInstrumentProp();  
	 
	 
	 ClassPathXmlApplicationContext autoWirecontext = new ClassPathXmlApplicationContext
             ("autoWireConfiguration.xml");
             
	 SongWriterImpl songWriterAutoWire=(SongWriterImpl)autoWirecontext.getBean("autoWireExampleBean");
	 System.out.println("Song writer firstname is: "+ songWriterAutoWire.getFirstname());
	 System.out.println("Song writer lastname is: "+ songWriterAutoWire.getLastname());
	 System.out.println("Song writer age is: "+ songWriterAutoWire.getAge());
	System.out.println("Song writer song name is: "+ songWriterAutoWire.getSong().getName()+ 
	" lyrics: "+songWriterAutoWire.getSong().getLyrics());   
		
	SingerImpl singerAutoWireByType=(SingerImpl)autoWirecontext.getBean("autoWireExampleByTypeBean");
	System.out.println("Singer firstname is: "+ singerAutoWireByType.getFirstname());
	System.out.println("Singer lastname is: "+ singerAutoWireByType.getLastname());
	System.out.println("Singer age is: "+ singerAutoWireByType.getAge());
	System.out.println("Singer song name is: "+ singerAutoWireByType.getSong().getName()+ " lyrics: "+singerAutoWireByType.getSong().getLyrics()); 
	
	SongWriterImpl autoWirebyConstructor=(SongWriterImpl)autoWirecontext.getBean("autoWirebyConstructor");
	System.out.println("Song writer firstname is: "+ autoWirebyConstructor.getFirstname());
	System.out.println("Song writer lastname is: "+ autoWirebyConstructor.getLastname());
	System.out.println("Song writer age is: "+ autoWirebyConstructor.getAge());
	System.out.println("Song writer song name is: "+ autoWirebyConstructor.getSong().getName()+ " lyrics: "+autoWirebyConstructor.getSong().getLyrics());
		}
}
