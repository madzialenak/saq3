package com.lab3.factories;

import com.lab3.domain.Euro;
import com.lab3.domain.Pounds;
import com.lab3.interfaces.Currency;

public class CurrencyFactory {

	public static Currency createCurrency (String country) {
	       if (country.equalsIgnoreCase ("Ireland")){
	              return new Euro();
	       }else if(country.equalsIgnoreCase ("England")){
	              return new Pounds();
	       }
	       else return null;
	  }	 
	
}
